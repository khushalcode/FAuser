/**
 * (tabs) layout — uses expo-router's Tabs but with a CUSTOM BottomNav
 * (Blinkit-style: Home, Order Again, Categories, Offers, raised red Orders).
 *
 * The default tab bar is replaced via `tabBar={() => <BottomNav />}` so the
 * navigation graph still works (each tab is a real route) but the UI is
 * fully custom. Each screen has headerShown: false — the home screen draws
 * its own StickyHeader.
 */
import React from 'react';
import { Tabs } from 'expo-router';
import { colors } from '@/theme/colors';
import { BottomNav } from '@/components/BottomNav';
import { useCartStore } from '@/store/cart';

export default function TabsLayout() {
  // Use the cart item count as a proxy for "active orders" badge on the
  // Orders button. In a real app this would be replaced with the actual
  // active-order count from the orders store.
  const cartCount = useCartStore((s) => s.itemCount());

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        // Hide the default tab bar — we render our own BottomNav instead.
        tabBarStyle: { display: 'none' }
      }}
      tabBar={() => <BottomNav cartCount={cartCount} />}
    >
      <Tabs.Screen name="index" options={{ title: 'Home' }} />
      <Tabs.Screen name="categories" options={{ title: 'Categories' }} />
      <Tabs.Screen name="cart" options={{ title: 'Cart' }} />
      <Tabs.Screen name="orders" options={{ title: 'Orders' }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile' }} />
    </Tabs>
  );
}
