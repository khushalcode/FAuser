/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{ts,tsx}', './src/**/*.{ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#10B981',
          dark: '#059669',
          light: '#D1FAE5',
          50: '#ECFDF5',
          100: '#D1FAE5',
          200: '#A7F3D0',
          300: '#6EE7B7',
          400: '#34D399',
          500: '#10B981',
          600: '#059669',
          700: '#047857',
          800: '#065F46',
          900: '#064E3B'
        },
        food: '#F59E0B',
        foodLight: '#FEF3C7',
        grocery: '#10B981',
        groceryLight: '#D1FAE5',
        surface: '#F9FAFB',
        surfaceAlt: '#F3F4F6',
        ink: '#18181B',
        textmain: '#18181B',
        muted: '#71717A',
        subtle: '#A1A1AA',
        line: '#E4E4E7',
        lineLight: '#F4F4F5'
      },
      borderRadius: {
        'xl2': '0.75rem'
      },
      fontFamily: {
        sans: ['System']
      }
    }
  },
  plugins: []
};
