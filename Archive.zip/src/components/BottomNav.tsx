/**
 * BottomNav — premium floating pill bottom navigation (Blinkit/Zomato style).
 *
 * Features:
 *   - Floating rounded pill design with shadow
 *   - Active tab: filled emerald color with top indicator bar
 *   - 5 tabs: Home, Categories, Cart, Orders, Account
 *   - Cart badge shows item count
 */
import React from 'react';
import { View, Pressable, Text, StyleSheet, Platform } from 'react-native';
import { Home, LayoutGrid, ShoppingCart, ClipboardList, User } from 'lucide-react-native';
import { colors } from '@/theme/colors';
import { useRouter, usePathname } from 'expo-router';

interface Props {
  /** Cart item count for badge */
  cartCount?: number;
  /** Active orders count for badge */
  activeOrders?: number;
}

export function BottomNav({ cartCount = 0, activeOrders = 0 }: Props) {
  const router = useRouter();
  const pathname = usePathname();

  const isActive = (route: string) => {
    if (route === '/' || route === '/(tabs)') {
      return pathname === '/' || pathname === '/(tabs)' || pathname.endsWith('/index') || pathname === '/(tabs)/index';
    }
    if (route === 'cart') return pathname.includes('/cart');
    if (route === 'orders') return pathname.includes('/orders');
    if (route === 'categories') return pathname.includes('/categories');
    if (route === 'profile') return pathname.includes('/profile');
    return pathname.includes(route);
  };

  const go = (route: string) => {
    // Use replace so back button doesn't pile up tab switches
    router.replace(route as any);
  };

  return (
    <View style={styles.wrap}>
      <View style={styles.pill}>
        <Item
          label="Home"
          active={isActive('/') || isActive('(tabs)')}
          onPress={() => go('/(tabs)')}
          renderIcon={(c, s, a) => <Home size={s} color={c} fill={a ? c : 'transparent'} strokeWidth={2.2} />}
        />
        <Item
          label="Categories"
          active={isActive('categories')}
          onPress={() => go('/(tabs)/categories')}
          renderIcon={(c, s, a) => <LayoutGrid size={s} color={c} fill={a ? c : 'transparent'} strokeWidth={2.2} />}
        />
        <Item
          label="Cart"
          active={isActive('cart')}
          onPress={() => go('/(tabs)/cart')}
          renderIcon={(c, s, a) => <ShoppingCart size={s} color={c} fill={a ? c : 'transparent'} strokeWidth={2.2} />}
          badge={cartCount}
        />
        <Item
          label="Orders"
          active={isActive('orders')}
          onPress={() => go('/(tabs)/orders')}
          renderIcon={(c, s, a) => <ClipboardList size={s} color={c} fill={a ? c : 'transparent'} strokeWidth={2.2} />}
          badge={activeOrders}
        />
        <Item
          label="Account"
          active={isActive('profile')}
          onPress={() => go('/(tabs)/profile')}
          renderIcon={(c, s, a) => <User size={s} color={c} fill={a ? c : 'transparent'} strokeWidth={2.2} />}
        />
      </View>
    </View>
  );
}

interface ItemProps {
  label: string;
  active: boolean;
  onPress: () => void;
  renderIcon: (color: string, size: number, active: boolean) => React.ReactNode;
  badge?: number;
}

function Item({ label, active, onPress, renderIcon, badge }: ItemProps) {
  const color = active ? colors.primary : colors.textMuted;
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.item, { opacity: pressed ? 0.7 : 1 }]}
    >
      <View style={{ position: 'relative' }}>
        {renderIcon(color, 22, active)}
        {badge && badge > 0 ? (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{badge}</Text>
          </View>
        ) : null}
      </View>
      <Text style={[styles.itemLabel, { color }]}>{label}</Text>
      {active && <View style={styles.activeBar} />}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 12,
    paddingBottom: Platform.OS === 'ios' ? 28 : 14,
    paddingTop: 8,
    zIndex: 100,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: colors.borderLight,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 12,
  },
  item: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 4,
    position: 'relative',
  },
  itemLabel: {
    fontSize: 10,
    fontWeight: '700',
    marginTop: 3,
  },
  activeBar: {
    position: 'absolute',
    top: -8,
    width: 24,
    height: 3,
    borderRadius: 1.5,
    backgroundColor: colors.primary,
  },
  badge: {
    position: 'absolute',
    top: -6,
    right: -10,
    minWidth: 16,
    height: 16,
    paddingHorizontal: 4,
    borderRadius: 8,
    backgroundColor: colors.error,
    borderWidth: 1.5,
    borderColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    fontSize: 9,
    fontWeight: '900',
    color: '#fff',
  },
});

export default BottomNav;
