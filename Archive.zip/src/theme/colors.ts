export const colors = {
  primary: '#10B981',         // emerald 500
  primaryDark: '#059669',     // emerald 600
  primaryLight: '#D1FAE5',    // emerald 100
  primary50: '#ECFDF5',
  primary100: '#D1FAE5',
  primary200: '#A7F3D0',
  primary300: '#6EE7B7',
  primary400: '#34D399',
  primary500: '#10B981',
  primary600: '#059669',
  primary700: '#047857',
  primary800: '#065F46',
  primary900: '#064E3B',

  background: '#FFFFFF',
  surface: '#F9FAFB',
  surfaceAlt: '#F3F4F6',

  text: '#18181B',
  textMuted: '#71717A',
  textSubtle: '#A1A1AA',

  border: '#E4E4E7',
  borderLight: '#F4F4F5',

  error: '#EF4444',
  errorLight: '#FEE2E2',
  warning: '#F59E0B',
  warningLight: '#FEF3C7',
  success: '#10B981',
  successLight: '#D1FAE5',
  info: '#3B82F6',
  infoLight: '#DBEAFE',

  food: '#F59E0B',
  foodLight: '#FEF3C7',
  grocery: '#10B981',
  groceryLight: '#D1FAE5',

  // Premium accent colors per food category
  amber: '#F59E0B',
  amberLight: '#FEF3C7',
  pink: '#EC4899',
  pinkLight: '#FCE7F3',
  purple: '#8B5CF6',
  purpleLight: '#EDE9FE',
  cyan: '#06B6D4',
  cyanLight: '#CFFAFE',
  orange: '#F97316',
  orangeLight: '#FFEDD5',
  teal: '#14B8A6',
  tealLight: '#CCFBF1',
  slate: '#64748B',
  slateLight: '#F1F5F9',

  // Order status colors
  pending: '#F59E0B',
  accepted: '#3B82F6',
  preparing: '#8B5CF6',
  ready: '#06B6D4',
  picked_up: '#F97316',
  on_the_way: '#F97316',
  delivered: '#10B981',
  cancelled: '#EF4444',
  rejected: '#EF4444'
} as const;

export type ColorKey = keyof typeof colors;
